
@extends('layouts.master')

@push('styles')

@endpush

@section('master-title', '')

@section('master-content')

@endsection

@push('scripts')
    <script>
    </script>
@endpush
