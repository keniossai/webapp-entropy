<!--begin::Global Javascript Bundle(mandatory for all pages)-->
<script src="{{ URL::asset('assets/plugins/global/plugins.bundle.js') }}"></script>
<script src="{{ URL::asset('assets/js/scripts.bundle.js') }}"></script>
<!--end::Global Javascript Bundle-->
