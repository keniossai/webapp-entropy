@extends('layouts.master')

@section('master-title', '')
@push('styles')

@endpush

@section('master-content')


@endsection


@push('scripts')



@endpush
